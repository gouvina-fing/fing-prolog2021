- En la carpeta lab1 se encuentra el informe del laboratorio 1 y el archivo lab1.pl con los predicados transpuesta y primos actualizados,
arreglando los errores correspondientes que se enviaron en la entrega del laboratorio 1.
- En la carpeta lab2 se encuentra el informe del laboratorio 2 y el archivo arabelog.pl, con todos los predicados correspondientes al
laboratorio 2.